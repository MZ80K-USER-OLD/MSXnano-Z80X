DEFINE M2TEST
INCLUDE "index16_test.asm"
