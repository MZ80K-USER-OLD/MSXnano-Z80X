module MSXnano_CPU_Wrapper24 #(
    parameter integer Mode,
    parameter integer IOWait
)(
    input  wire        RESET_n,
    input  wire        CLK_n,
    input  wire        clk_enable,
    input  wire        clk_falling,
    input  wire        WAIT_n,
    input  wire        INT_n,
    input  wire        NMI_n,
    input  wire        BUSRQ_n,
    output wire        M1_n,
    output wire        MREQ_n,
    output wire        IORQ_n,
    output wire        RD_n,
    output wire        WR_n,
    output wire        RFSH_n,
    output wire        HALT_n,
    output wire        BUSAK_n,
    output wire [23:0] A,
    output wire        update_addr,
    input  wire [7:0]  DI,
    output wire [7:0]  DO,
    output wire [1:0]  mode24,
    output wire [7:0]  bank_bc,
    output wire [7:0]  bank_de,
    output wire [7:0]  bank_hl,
    output wire [7:0]  bank_ix,
    output wire [7:0]  bank_iy,
    output wire [7:0]  bank_pc,
    output wire [7:0]  bank_msp,
    output wire [7:0]  bank_int,
    output wire [7:0]  bank_nvr,
    output wire [7:0]  bank_rst,
    output wire        Data_Reverse
);

    wire [15:0] cpu_addr;
    wire [7:0]  cpu_a_bank;

    // Phase3: 24bit logical address = {bank byte, 16bit address}.
    // cpu_a_bank is 00h for M0 and for PC/SP/direct(nn) accesses in M1/M2
    // (see T80.vhd Set_Addr_To case), so this preserves the exact legacy
    // {8'b0, cpu_addr} behaviour until register-indirect (HL/BC/DE/(IX+d)/
    // (IY+d)) data accesses in M1/M2 start producing a non-zero bank byte.
    assign A = {cpu_a_bank, cpu_addr};

    G80a  #(
        .Mode    (Mode),  // 0 => Z80, 1 => Fast Z80, 2 => 8080, 3 => GB
        //.T2Write (0),     //0 => WR_n active in T3, /=0 => WR_n active in T2
        .IOWait   (IOWait) // 0 => Single I/O cycle, 1 => Std I/O cycle
    ) cpu1 (
        .RESET_n      (RESET_n),
        .CLK_n        (CLK_n),
        .clk_enable   (clk_enable),
        .clk_falling  (clk_falling),
        .WAIT_n       (WAIT_n),
        .INT_n        (INT_n),
        .NMI_n        (NMI_n),
        .BUSRQ_n      (BUSRQ_n),
        .M1_n         (M1_n),
        .MREQ_n       (MREQ_n),
        .IORQ_n       (IORQ_n),
        .RD_n         (RD_n),
        .WR_n         (WR_n),
        .RFSH_n       (RFSH_n),
        .HALT_n       (HALT_n),
        .BUSAK_n      (BUSAK_n),
        .A            (cpu_addr),
        .update_addr  (update_addr),
        .A_Bank       (cpu_a_bank),
        .DI           (DI),
        .DO           (DO),
        .mode24       (mode24),
        .bank_bc      (bank_bc),
        .bank_de      (bank_de),
        .bank_hl      (bank_hl),
        .bank_ix      (bank_ix),
        .bank_iy      (bank_iy),
        .bank_pc      (bank_pc),
        .bank_msp     (bank_msp),
        .bank_int     (bank_int),
        .bank_nvr     (bank_nvr),
        .bank_rst     (bank_rst),
        .Data_Reverse (Data_Reverse)
    );

endmodule
