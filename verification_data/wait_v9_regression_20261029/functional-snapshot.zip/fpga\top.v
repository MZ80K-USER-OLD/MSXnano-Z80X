`define ENABLE_V9958
`define ENABLE_BIOS
`define ENABLE_SOUND //v9958, bios required
`define ENABLE_MAPPER //bios required
`define ENABLE_SCAN_LINES
`define ENABLE_SDCARD
`define ENABLE_CONFIG
`define SDRAM_32
`define USE_DOCK_JOISTICK
`define ENABLE_WAIT //extra wait state for mreq+wr
// `define SWAP23
`define ENABLE_PS2KEYBOARD

module top
#(
    parameter SD_SLOT = 3 // 3
)(
    input wire ex_clk_27m,
    input wire s1,
    input wire s2,

    // input wire ex_bus_wait_n,
    // input wire ex_bus_int_n,
    // input wire ex_bus_reset_n,
    // input wire ex_bus_clk_3m6,

    // inout wire [7:0] ex_bus_data,
    
	// interface to external FPGA companion - USB KEYBOARD and gamepads
	inout wire [4:0]	m0s,

`ifndef USE_DOCK_JOISTICK
    //connection is used with a M0S Dock
	input wire	spi_sclk,
	input wire	spi_csn,
	output wire	spi_dir,
	input wire	spi_dat,
	output wire	spi_irqn,
`endif

    // output wire [1:0] ex_msel,
    // output wire ex_bus_m1_n,
    // output wire ex_bus_rfsh_n,
    // output wire ex_bus_mreq_n,
    // output wire ex_bus_iorq_n,
    // output wire ex_bus_rd_n,
    // output wire ex_bus_wr_n,

    // output wire ex_bus_data_reverse_n,
    //output wire ex_bus_data_reverse,
    // output wire [7:0] ex_bus_mp,

    //hdmi out
    output wire [2:0] data_p,
    output wire [2:0] data_n,
    output wire clk_p,
    output wire clk_n,

    // flash
    output wire mspi_cs,
    output wire mspi_sclk,
    inout wire mspi_miso,
    inout wire mspi_mosi,

    // MicroSD
    output wire sd_sclk,
    inout wire sd_cmd,      // MOSI
    inout  wire sd_dat0,     // MISO
    output wire sd_dat1,     // 1
    output wire sd_dat2,     // 1
    output wire sd_dat3,     // 1

    //uart
    //output wire uart_tx,
    output wire uart_tx,


    output reg [5:0] led, 

    // Magic ports for SDRAM to be inferred
    output wire O_sdram_clk,
    output wire O_sdram_cke,
    output wire O_sdram_cs_n, // chip select
    output wire O_sdram_cas_n, // columns address select
    output wire O_sdram_ras_n, // row address select
    output wire O_sdram_wen_n, // write enable
    inout wire [31:0] IO_sdram_dq, // 32 bit bidirectional data bus
    output wire [10:0] O_sdram_addr, // 11 bit multiplexed address bus
    output wire [1:0] O_sdram_ba, // two banks
    output wire [3:0] O_sdram_dqm // 32/4

    //output wire SLTSL3

`ifdef ENABLE_PS2KEYBOARD
    ,
    // ★一番最後など（カッコを閉じる前）に、PS/2物理ピンの定義を2行追加
    inout  wire        ps2_clk,
    inout  wire        ps2_data,
`endif
`ifdef USE_DOCK_JOISTICK
    // Tang Nano 20K DOCK joystick interface
    // pin 71 = JS_Clk / PHI2, pin 72 = JS_Load_N, pin 76 = JS_Data
    output wire        js_clk,
    output wire        js_load_n,
    input  wire        js_data
`endif    
);

initial begin

end
    //`default_nettype none

    //assign SLTSL3 = bus_mreq_disable ^ bus_iorq_disable ^ xffh ^ xffl ^ mapper_read ^ exp_slotx_req_r ^ bios_req ^ subrom_req ^ vdp_csr_n;

wire [7:0] ex_bus_data;

    wire ex_bus_wait_n  = 1'b1;
    wire ex_bus_int_n   = 1'b1;

    wire clock_locked;

    wire ex_bus_reset_n;
    assign ex_bus_reset_n = ~s1 && clock_locked;

    // 108 MHz / 30 = 3.6 MHz
    reg [4:0] div30_cnt;
    reg clk_3m6_internal;

    //clocks
    wire clk_108m;
    wire clk_108m_n;
    
    CLK_108P clk_main (
        .clkout(clk_108m), //output clkout
        .lock(clock_locked), //output lock
        .clkoutp(clk_108m_n), //output clkoutp
        .reset(0), //input reset
        .clkin(ex_clk_27m) //input clkin
    );

    wire clk_enable_27m;
    wire clk_enable_54m;
    reg [1:0] cnt_clk_enable_27m;
    always @ (posedge clk_108m) begin
        cnt_clk_enable_27m <= cnt_clk_enable_27m + 1;
    end
    assign clk_enable_27m = ( cnt_clk_enable_27m == 2'b00 ) ? 1: 0;
    assign clk_enable_54m = ( cnt_clk_enable_27m[0] == 1 ) ? 1: 0;

    wire clk_27m;
//    BUFG buf1 (
//        .O(clk_27m),
//        .I(ex_clk_27m)
//    );
//    assign clk_27m = ex_clk_27m;
    Gowin_CLKDIV div4(
        .clkout(clk_27m), //output clkout
        .hclkin(clk_108m), //input hclkin
        .resetn(1) //input resetn
    );

    wire clk_54m;
    Gowin_CLKDIV2 div2(
        .clkout(clk_54m), //output clkout
        .hclkin(clk_108m), //input hclkin
        .resetn(1) //input resetn
    );

//    wire clk_54m;
//    wire clk_54m_buf;
//    Gowin_rPLL pll(
//        .clkout(clk_54m_buf), //output clkout
//        .clkin(ex_clk_27m) //input clkin
//    );

//    BUFG buf2(
//        .O(clk_54m),
//        .I(clk_54m_buf)
//    );

    wire bus_clk_3m6;
    PINFILTER dn1(
        .clk(clk_54m),
        .reset_n(1),
        .din(ex_bus_clk_3m6),
        .dout(bus_clk_3m6)
    );

//    wire clk_enable_3m6;
//    wire clk_falling_3m6;
//    reg bus_clk_3m6_prev;
//    always @ (posedge clk_54m) begin
//        bus_clk_3m6_prev <= bus_clk_3m6;
//    end
//    assign clk_enable_3m6 = (bus_clk_3m6_prev == 0 && bus_clk_3m6 == 1);
//    assign clk_falling_3m6 = (bus_clk_3m6_prev == 1 && bus_clk_3m6 == 0);

    reg bus_clk_3m6_27;
    reg bus_clk_3m6_27_0;
    reg bus_clk_3m6_27_1;
    reg bus_clk_3m6_27_2;
    reg bus_clk_3m6_27_3;
    reg bus_clk_3m6_27_4;
    reg bus_clk_3m6_27_5;
    reg bus_clk_3m6_27_6;
//    PINFILTER dn5(
//        .clk(clk_27m),
//        .reset_n(1),
//        .din(ex_bus_clk_3m6),
//        .dout(bus_clk_3m6_27)
//    );
    always @ (posedge clk_27m) begin
        bus_clk_3m6_27_6 <= bus_clk_3m6;
        bus_clk_3m6_27_5 <= bus_clk_3m6_27_6;
        bus_clk_3m6_27_4 <= bus_clk_3m6_27_5;
        bus_clk_3m6_27_3 <= bus_clk_3m6_27_4;
        bus_clk_3m6_27_2 <= bus_clk_3m6_27_3;
        bus_clk_3m6_27_1 <= bus_clk_3m6_27_2;
        bus_clk_3m6_27_0 <= bus_clk_3m6_27_1;
        bus_clk_3m6_27 <= bus_clk_3m6_27_0;
    end

    wire clk_enable_3m6_27;
    wire clk_falling_3m6_27;
    reg bus_clk_3m6_prev_27;
    always @ (posedge clk_27m) begin
        bus_clk_3m6_prev_27 <= bus_clk_3m6_27;
    end
    assign clk_enable_3m6_27 = (bus_clk_3m6_prev_27 == 0 && bus_clk_3m6_27 == 1);
    assign clk_falling_3m6_27 = (bus_clk_3m6_prev_27 == 1 && bus_clk_3m6_27 == 0);



    wire clk_enable_3m6_54;
    wire clk_falling_3m6_54;
    reg bus_clk_3m6_54;
    reg bus_clk_3m6_prev_54;
    always @ (posedge clk_54m) begin
        bus_clk_3m6_54 <= bus_clk_3m6;
        bus_clk_3m6_prev_54 <= bus_clk_3m6_54;
    end
    assign clk_enable_3m6_54 = (bus_clk_3m6_prev_54 == 0 && bus_clk_3m6_54 == 1);
    assign clk_falling_3m6_54 = (bus_clk_3m6_prev_54 == 1 && bus_clk_3m6_54 == 0);



    wire bus_wait_n;
    PINFILTER dn2(
        .clk(clk_54m),
        .reset_n(1),
        .din(ex_bus_wait_n),
        .dout(bus_wait_n)
    );

    // wire bus_reset_n;
    // PINFILTER dn3(
    //     .clk(clk_54m),
    //     .reset_n(1),
    //     .din(ex_bus_reset_n & ~config_reset),
    //     .dout(bus_reset_n)
    // );

    wire bus_reset_n = ex_bus_reset_n;


    always @(posedge clk_108m or negedge bus_reset_n) begin
        if (~bus_reset_n) begin
            div30_cnt <= 0;
            clk_3m6_internal <= 0;
        end else begin
            if (div30_cnt == 5'd14) begin
                clk_3m6_internal <= ~clk_3m6_internal;
                div30_cnt <= 0;
            end else begin
                div30_cnt <= div30_cnt + 1;
            end
        end
    end

    wire ex_bus_clk_3m6;
    assign  ex_bus_clk_3m6 = clk_3m6_internal;




    wire bus_int_n;
//    PINFILTER dn4(
//        .clk(clk_108m),
//        .reset_n(1),
//        .din(ex_bus_int_n),
//        .dout(bus_int_n)
//    );
    denoise dn4 (
		.data_in (ex_bus_int_n),
		.clock(clk_54m),
		.data_out (bus_int_n)
    );

    reg [7:0] bus_data;
    genvar i;
    generate
        for (i = 0; i <= 7; i++)
        begin: bus_din
            PINFILTER dn(
                .clk(clk_54m),
                .reset_n(1),
                .din(ex_bus_data[i]),
                //.din(),

                .dout(bus_data[i])
            );
//            denoise2 dn (
//                .data_in (ex_bus_data[i]),
//                .clock(clk_108m),
//                .data_out (bus_data[i])
//            );
        end
    endgenerate

//    always @ (posedge clk_108m) begin
//        bus_data <= ex_bus_data;
//    end

    //startup logic
    reg reset1_n_ff;
    reg reset2_n_ff;
    reg reset3_n_ff;
    wire reset1_n;
    wire reset2_n;
    wire reset3_n;

    reg [20:0] counter_reset = 0;
    reg [1:0] rst_seq;
    reg rst_step;

    always @ (posedge clk_27m or negedge bus_reset_n) begin
        if (bus_reset_n == 0) begin
            rst_step <= 0;
            counter_reset <= 0;
        end
        else begin
            rst_step <= 0;
            if ( counter_reset <= 21'b100000000000000000000 ) 
                counter_reset <= counter_reset + 1;
            else begin
                rst_step <= 1;
                counter_reset <= 0;
            end
        end
    end

    always @ (posedge clk_27m or negedge bus_reset_n ) begin
        if (bus_reset_n == 0 ) begin
            rst_seq <= 2'b00;
            reset1_n_ff <= 0;
            reset2_n_ff <= 0;
            reset3_n_ff <= 0;
        end
        else begin
            case ( rst_seq )
                2'b00: 
                    if (rst_step == 1 ) begin
                        reset1_n_ff <= 1;
                        rst_seq <= 2'b01;
                    end
                2'b01: 
                    if (rst_step == 1) begin
                        reset2_n_ff <= 1;
                        rst_seq <= 2'b10;
                    end
                2'b10:
                    if (rst_step == 1) begin
                        reset3_n_ff <= 1;
                        rst_seq <= 2'b11;
                    end
            endcase
        end
    end
    assign reset1_n = reset1_n_ff;
    assign reset2_n = reset2_n_ff;
    assign reset3_n = reset3_n_ff;

    //bus demux
    reg [1:0] msel;
    reg [7:0] bus_mp;
//    reg msel_ff = 0;
    reg [4:0] mp_cnt;
    wire [15:0] bus_addr;
    wire [23:0] cpu_addr24;
    wire [1:0] cpu_mode24;
    wire [7:0] cpu_bank_bc;
    wire [7:0] cpu_bank_de;
    wire [7:0] cpu_bank_hl;
    wire [7:0] cpu_bank_ix;
    wire [7:0] cpu_bank_iy;
    wire [7:0] cpu_bank_pc;
    wire [7:0] cpu_bank_msp;
    wire [7:0] cpu_bank_int;
    wire [7:0] cpu_bank_nvr;
    wire [7:0] cpu_bank_rst;
    // Z80X24 base spec: straight-through logical->physical bank mapping
    // (no MMU translation table). See the cpu_sdram_* section below for
    // the full rationale and how to re-add the optional MMU24 wrapper
    // (fpga/G80A/mmu24.vhd) later if bank remapping/write-protection is
    // needed again.
    wire [7:0] mmu_physical_bank;
    assign ex_msel = msel;
    assign ex_bus_mp = bus_mp;
//    assign msel = { msel_ff, ~ msel_ff };
//    assign bus_mp = ( msel[1] == 1 ) ? bus_addr[15:8] : bus_addr[7:0];

//    always @ (posedge clk_108m) begin
//        if (cnt_clk_enable_27m == 1) begin
//            msel_ff <= ~ msel_ff;
//        end
//    end

    localparam IDLE = 2'd0;
    localparam LATCH = 2'd1;
    localparam FINISH1 = 2'd3;
    localparam FINISH2 = 2'd2;
    localparam [3:0] TON = 4'd3;
    localparam [3:0] TP = 4'd1; //prefetch time
    reg [1:0] state_demux;
    reg [3:0] counter_demux;
    //reg [15:0] bus_addr_demux;
    reg low_byte_demux;
    wire update_demux;
    assign bus_mp = ( low_byte_demux == 0 ) ? bus_addr[15:8] : bus_addr[7:0];
    always @ (posedge clk_108m) begin
        if (~bus_reset_n) begin
            state_demux <= LATCH;
            counter_demux <= 4'd0;
            //bus_addr_demux <= ~ bus_addr;
            low_byte_demux <= 0;
        end 
        else begin
            counter_demux = counter_demux + 4'd1;
            casex ({state_demux, counter_demux})
                {IDLE, 4'bxxxx}: begin
                    msel <= 2'b00;
                    counter_demux <= 4'd0;
                    low_byte_demux <= 0;
                    if (update_addr == 1 ) begin
                        state_demux <= LATCH;
                    end
                end
                {LATCH, 4'd1} : begin
                    //bus_addr_demux <= bus_addr;
                    msel[1] <= 1;
                end
                {LATCH, 4'd1 + TON} : begin
                    msel[1] <= 0;
                end
                {LATCH, 4'd1 + TON + TP} : begin
                    low_byte_demux <= 1;
                end
                {LATCH, 4'd1 + TON + TP + TP} : begin
                    msel[0] <= 1;
                end
                {LATCH, 4'd1 + TON + TP + TP + TON} : begin
                    msel[0] <= 0;
                    msel[1] <= 0;
                    state_demux <= FINISH1;
                end
                {FINISH1, 4'bxxxx}: begin
                    if (update_addr == 0 ) begin
                        state_demux <= IDLE;
                    end
                end
                {FINISH2, 4'bxxxx}: begin
                    if (update_addr == 0 ) begin
                        state_demux <= IDLE;
                    end
                end
            endcase
        end
    end




    //bus isolation
    wire bus_data_reverse;
    wire bus_m1_n;
    wire bus_mreq_n;
    wire cpu_mreq_n;
    wire [23:0] extended_addr;
    wire extended_mreq_n;
    wire extended_access;
    wire bus_iorq_n;
    wire bus_rd_n;
    wire bus_wr_n;
    wire bus_rfsh_n;
    reg [7:0] cpu_din;
    wire [7:0] cpu_dout;
    wire bus_mreq_disable;
    wire bus_iorq_disable;
    wire bus_disable;
    assign ex_bus_m1_n = bus_m1_n;
    assign ex_bus_rfsh_n = bus_rfsh_n;
    assign ex_bus_data_reverse_n = ~ bus_data_reverse;
    //assign ex_bus_data_reverse = bus_data_reverse;
    //assign ex_bus_mreq_n = bus_mreq_n;
    //assign ex_bus_iorq_n = bus_iorq_n;
    //assign ex_bus_rd_n = bus_rd_n;
    //assign ex_bus_wr_n = bus_wr_n;

    assign bus_mreq_disable = 0;
    assign bus_iorq_disable = (
                                0
                        `ifdef ENABLE_V9958
                                || vdp_csr_n == 0 || vdp_csw_n == 0 
                        `endif 
                                ) ? 1 : 0;

    assign bus_disable = bus_mreq_disable | bus_iorq_disable;
//    assign ex_bus_data = ( bus_data_reverse == 1 && slot0_req_w == 0 ) ? cpu_dout : 
//                         ( slot0_req_w == 1 ) ? 8'hff :  8'hzz;
`ifndef SWAP23
    assign ex_bus_data =  ( bus_data_reverse == 1 ) ? cpu_dout : 8'hzz;
`else

    function [1:0] swap;
        input [1:0] entrada;
        begin
            case (entrada)
                2'b00: swap = 2'b00;
                2'b01: swap = 2'b01;
                2'b10: swap = 2'b11;
                2'b11: swap = 2'b10;
                default: swap = 2'b00; // Por seguridad
            endcase
        end
    endfunction

    wire [7:0] cpu_dout_swap;
    assign cpu_dout_swap = { swap(cpu_dout[7:6]), swap(cpu_dout[5:4]), swap(cpu_dout[3:2]), swap(cpu_dout[1:0]) };

    reg ppi_swap;
    always @ (posedge clk_27m) begin
        if (~bus_reset_n) begin
            ppi_swap <= 0;
        end
        else begin
            if (ppi_swap == 0) begin
                if (bus_data_reverse == 1  && ppi_req_w == 1) begin
                    ppi_swap <= 1;
                end
            end
            else begin
                if (bus_data_reverse == 0) begin
                    ppi_swap <= 0;
                end
            end
        end
    end

    assign ex_bus_data =  ( bus_data_reverse == 1  && ppi_swap == 0) ? cpu_dout : 
                          ( bus_data_reverse == 1  && ppi_swap == 1) ? cpu_dout_swap : 8'hzz;
`endif

//joystick
wire psg_req_r;
assign psg_req_r = (bus_addr[7:0] == 8'hA2 && bus_iorq_n == 0 && bus_m1_n == 1 && bus_rd_n == 0) ? 1 : 0;

`ifdef USE_DOCK_JOISTICK
// ------------------------------------------------------------------------
// Tang Nano 20K DOCK joystick
// ------------------------------------------------------------------------
wire        dock_phi2;
wire [7:0]  dock_psg_ioa;
wire [7:0]  dock_psg_iob;

assign dock_phi2 = ex_bus_clk_3m6;
assign js_clk    = dock_phi2;

msxnano_dock_joystick dock_joystick1 (
    .clock     (clk_27m),
    .reset_n   (bus_reset_n),
    .phi2      (dock_phi2),
    .js_data   (js_data),
    .js_load_n (js_load_n),
    .psg_r15   (dock_psg_iob),
    .psg_ioa   (dock_psg_ioa)
);
`endif

//keyboard scan
wire ppi_portb_req_r = (bus_addr[7:0] == 8'hA9 && bus_iorq_n == 0 && bus_m1_n == 1 && bus_rd_n == 0) ? 1 : 0;
wire ppi_portc_req_r = (bus_addr[7:0] == 8'hAA && bus_iorq_n == 0 && bus_m1_n == 1 && bus_rd_n == 0);
wire ppi_portc_req_w = (bus_addr[7:0] == 8'hAA && bus_iorq_n == 0 && bus_m1_n == 1 && bus_wr_n == 0);

wire [3:0] keyboard_addr;
reg [7:0] keyboard_data;
wire [1:12] function_keys;

reg [7:0] ppi_port_c = 8'h00;

always @(posedge clk_54m or negedge bus_reset_n) begin
    if (!bus_reset_n)
        ppi_port_c <= 8'h00;
    else if (ppi_portc_req_w)
        ppi_port_c <= cpu_dout;
end

assign  keyboard_addr = ppi_port_c[3:0];

// mapper registers
reg [7:0] mapper_reg_fc;
reg [7:0] mapper_reg_fd;
reg [7:0] mapper_reg_fe;
reg [7:0] mapper_reg_ff;

// write to mapper
always @(posedge clk_54m) begin
    if (bus_iorq_n == 0 && bus_wr_n == 0 && bus_m1_n == 1) begin
        case (bus_addr[7:0])
            8'hFC: mapper_reg_fc <= bus_data;
            8'hFD: mapper_reg_fd <= bus_data;
            8'hFE: mapper_reg_fe <= bus_data;
            8'hFF: mapper_reg_ff <= bus_data;
        endcase
    end
end

// mapper read
wire mapper_port_read = (bus_iorq_n == 0 && bus_rd_n == 0 && bus_m1_n == 1 &&
                         bus_addr[7:2] == 6'b111111);  // FC-FF

wire [7:0] mapper_read_data = 
    (bus_addr[1:0] == 2'b00) ? mapper_reg_fc :
    (bus_addr[1:0] == 2'b01) ? mapper_reg_fd :
    (bus_addr[1:0] == 2'b10) ? mapper_reg_fe :
                               mapper_reg_ff;

// Z80X24 base spec (no MMU): straight-through logical->physical bank
// mapping. cpu_addr24[23:16] is the Phase3 A_Bank (00h in M0, or for
// PC/SP/direct addressing; non-zero only for register-indirect data
// accesses in M1/M2 - see t80.vhd). mmu_physical_bank is wired directly
// into the physical SD-RAM address below (cpu_sdram_*), with no
// translation table, aliasing, or per-bank write protection.
//
// An MMU translation layer (F0h/F1h MMU_INDEX/MMU_DATA table lookup, plus
// F2h MMU_ATTR.W write protection) was previously implemented here as
// fpga/G80A/mmu24.vhd (Phase4/5/6), but was removed from this default
// build: on this project's current FPGA floorplan, BSRAM is already 100%
// allocated by other IP (mostly the BIOS/SUBROM/MSX-logo boot ROMs), so
// MMU24's two 256-entry tables could not be packed into real BSRAM and
// fell back to expensive LUT-based distributed RAM, costing roughly 12
// percentage points of Logic (LUT) utilization and 13 points of Register
// utilization project-wide - by far the single largest consumer among all
// Z80X24 Phase1-7 additions.
//
// mmu24.vhd itself is kept in the repository, fully implemented and still
// GHDL-verified in isolation (fpga/G80A/test/tb_phase4_mmu24.vhd,
// tb_phase5_mmu_mapping.vhd, tb_phase6_mmu_attr.vhd), as an optional
// add-on for projects/floorplans with spare BSRAM. To re-add it: reinstate
// its File entry in MSXNanoTang20K_Z80X24.gprj, replace the
// "assign mmu_physical_bank = ..." line below with an MMU24 instance
// (Logical_Bank => cpu_addr24[23:16], Physical_Bank => mmu_physical_bank,
// D_Out/D_OutEn wired into the cpu_din mux below, Write_Allow gating
// cpu_sdram_write), exactly as it was wired prior to this change.
assign mmu_physical_bank = cpu_addr24[23:16];

    always @ (posedge clk_54m) begin
        cpu_din <= 
                (extended_access==1) ? (cpu_sdram_bank_in_range ? cpu_sdram_dout : 8'hff) :
                (mapper_port_read==1) ? mapper_read_data :
                (psg_req_r == 1) ? psg_dout :
                (ppi_portb_req_r == 1) ? keyboard_data :
                `ifdef ENABLE_V9958
                     ( vdp_csr_n == 0) ? vdp_dout :
                `endif
                `ifdef ENABLE_MAPPER
                     ( mapper_read == 1) ? mapper_dout :
                `endif
                `ifdef ENABLE_BIOS
                     ( exp_slotx_req_r == 1) ? ~exp_slotx  :
                     ( bios_req == 1) ? bios_dout : 
                     ( subrom_req == 1) ? subrom_dout :
                     ( msx_logo_req == 1 ) ? msx_logo_dout :
                `endif
                `ifdef ENABLE_SDCARD
                     ( sd_busreq_w == 1) ? sd_cd_w :
                     ( sram_busreq_w == 1) ? sram_cd_w :
                     ( megarom_req == 1) ? ff_rom_dout :
                     //( slot3_req_r == 1) ? 8'hff :
                 `endif
                `ifdef ENABLE_SOUND
                     //( scc_req3_r == 1 ) ? scc_dout:
                     ( megaram_req == 1 ) ? megaram_dout:
                `endif
                     //( slot0_req_r == 1 || slot3_req_r == 1) ? 8'hff :
                `ifdef ENABLE_CONFIG
                     ( config_req == 1 && config_ok == 1) ? config_dout :
                     ( config_req == 1 && config_ok == 0) ? swio_dout :
                `endif
                     ( rtc_req_r == 1 ) ? rtc_dout :
                //`ifdef SWAP23
                     ( ppi_req_r == 1 ) ? ppi_port_a :
                //`endif
                     ( slotx_req_r == 1 ) ? 8'hff :
                      8'hFF; // bus_data;
    end


//    wire ex_bus_rd_n_test;
//    wire ex_bus_wr_n_test;
//    wire ex_bus_iorq_n_test;
//    wire ex_bus_mreq_n_test;
    reg ex_bus_rd_n_ff;
    reg ex_bus_wr_n_ff;
    reg ex_bus_iorq_n_ff;
    reg ex_bus_mreq_n_ff;
    localparam IDLE_ISO = 2'd0;
    localparam ACTIVE_ISO = 2'd1;
    localparam WAIT_ISO = 2'd2;
    reg [1:0] state_iso;
    reg [2:0] counter_iso;
    wire io_active;

    //assign ex_bus_rd_n = ( bus_rd_n | ex_bus_rd_n_ff | bus_disable);
    assign ex_bus_rd_n = bus_rd_n;
    //assign ex_bus_wr_n = ( bus_wr_n | ex_bus_wr_n_ff | bus_disable);
    assign ex_bus_wr_n = bus_wr_n;
    assign ex_bus_iorq_n = ( bus_iorq_n | bus_iorq_disable );
    assign ex_bus_mreq_n = ( bus_mreq_n | bus_mreq_disable );
    assign io_active = ( state_iso != IDLE_ISO ) ? 1 : 0;

    always @ ( posedge clk_108m ) begin
        if (~bus_reset_n) begin
            state_iso <= IDLE_ISO;
            ex_bus_rd_n_ff <= 1;
            ex_bus_wr_n_ff <= 1;
        end 
        else begin
            counter_iso = counter_iso + 3'd1;
            casex ({state_iso, counter_iso})
                {IDLE_ISO, 3'bxxx}: begin
                    ex_bus_rd_n_ff <= 1;
                    ex_bus_wr_n_ff <= 1;
                    counter_iso <= 3'd0;
                    if (bus_rd_n == 0 || bus_wr_n == 0 ) begin
                        state_iso <= ACTIVE_ISO;
                    end
                end
                {ACTIVE_ISO, 3'd2} : begin
                    ex_bus_rd_n_ff <= bus_rd_n;
                    ex_bus_wr_n_ff <= bus_wr_n;
                    state_iso <= WAIT_ISO;
                end
                {WAIT_ISO, 3'bxxx} : begin
                    if ( bus_rd_n == 1 && bus_wr_n == 1 ) begin
                        state_iso <= IDLE_ISO;
                    end
                end
            endcase
        end
    end

`ifdef ENABLE_WAIT
    wire wait_io;
    reg wait_io_ff = 1;
    reg [6:0] state_wait;
    localparam WAIT_IDLE = 7'd0;
    localparam WAIT_STATE1 = 7'd1;
    localparam WAIT_STATE2 = 7'd3;
    localparam WAIT_STATE3 = 7'd2;

    assign wait_io = wait_io_ff;
    always @ (posedge clk_54m) begin
        if (~bus_reset_n) begin
            state_wait <= IDLE;
            wait_io_ff <= 1;
        end 
        else begin
            case (state_wait)
                WAIT_IDLE: begin
                    if ( (ex_bus_iorq_n == 0 || ( config_enable_wait == 1 && ex_bus_mreq_n == 0 ) )&& (bus_rd_n == 0 || bus_wr_n == 0) ) begin
                        wait_io_ff <= 0;
                        state_wait <= WAIT_STATE1;
                    end
                end
                WAIT_STATE1: begin
                    if ( clk_enable_3m6_54 == 1 ) begin
                        state_wait <= WAIT_STATE2;
                    end
                end
                WAIT_STATE2: begin
                    if ( clk_falling_3m6_54 == 1 ) begin
                        wait_io_ff <= 1;
                        state_wait <= WAIT_STATE3;
                    end
                end
                WAIT_STATE3: begin
                    if ( bus_rd_n == 1 && bus_wr_n == 1) begin
                        state_wait <= WAIT_IDLE;
                    end
                end
            endcase
        end
    end
`endif

    wire update_addr;
    MSXnano_CPU_Wrapper24  #(
        .Mode    (0),     // 0 => Z80, 1 => Fast Z80, 2 => 8080, 3 => GB
        //.T2Write (0),     //0 => WR_n active in T3, /=0 => WR_n active in T2
        .IOWait   (1)      // 0 => Single I/O cycle, 1 => Std I/O cycle
    ) cpu1 (
        .RESET_n   (bus_reset_n & reset3_n),
        .CLK_n     (clk_54m),
`ifdef ENABLE_WAIT
		.clk_enable (clk_enable_3m6_54 & wait_io),
		.clk_falling (clk_falling_3m6_54 & wait_io),
`else
        .clk_enable (clk_enable_3m6_54),
		.clk_falling (clk_falling_3m6_54),
`endif
`ifdef ENABLE_SDCARD
        .WAIT_n    (bus_wait_n & flash_wait_n & cpu_sdram_wait_n),
`else
        .WAIT_n    (bus_wait_n & cpu_sdram_wait_n),
`endif
    `ifdef ENABLE_V9958
        .INT_n     (bus_int_n & vdp_int),
    `else
        .INT_n     (bus_int_n),
    `endif
        .NMI_n     (1),
        .BUSRQ_n   (1),
        .M1_n      (bus_m1_n),
        .MREQ_n    (cpu_mreq_n),
        .IORQ_n    (bus_iorq_n),
        .RD_n      (bus_rd_n),
        .WR_n      (bus_wr_n),
        .RFSH_n    (bus_rfsh_n),
        .HALT_n    ( ),
        .BUSAK_n   ( ),
        .A         (cpu_addr24),
        .update_addr(update_addr),
        .DI         (cpu_din),
        .DO         (cpu_dout),
        .mode24     (cpu_mode24),
        .bank_bc    (cpu_bank_bc),
        .bank_de    (cpu_bank_de),
        .bank_hl    (cpu_bank_hl),
        .bank_ix    (cpu_bank_ix),
        .bank_iy    (cpu_bank_iy),
        .bank_pc    (cpu_bank_pc),
        .bank_msp   (cpu_bank_msp),
        .bank_int   (cpu_bank_int),
        .bank_nvr   (cpu_bank_nvr),
        .bank_rst   (cpu_bank_rst),
        .Data_Reverse (bus_data_reverse)
    );
    memory_bus_router24 memory_bus (
        .cpu_addr(cpu_addr24),
        .cpu_mreq_n(cpu_mreq_n),
        .cpu_rd_n(bus_rd_n),
        .cpu_wr_n(bus_wr_n),
        .cpu_rfsh_n(bus_rfsh_n),
        .z80_addr(bus_addr),
        .z80_mreq_n(bus_mreq_n),
        .extended_addr(extended_addr),
        .extended_mreq_n(extended_mreq_n),
        .extended_access(extended_access)
    );

    //assign led[5:1] = cpu_din[5:1];

    // assign  led[5:1] = bus_addr[5:1];

    assign led[5:0] = keyboard_data[5:0];

    // assign led[5] = bus_reset_n;
    // assign led[4] = reset3_n;
    // assign led[3] = wait_io;
    // assign led[2] = bus_wait_n;
    // assign led[1] = flash_wait_n;

    reg [19:0] led_cnt;
    always @(posedge clk_enable_3m6_54 or negedge bus_reset_n) begin
        if (!bus_reset_n) begin
            led_cnt <= 0;
            //led[0] <= 0;
        end else begin
            if (led_cnt == 1000000-1) begin
                led_cnt <= 0;
                // led[0] <= ~led[0];      // przełącz LED
            end else begin
                led_cnt <= led_cnt + 1;
            end
        end
    end

    //slots decoding
    reg [7:0] ppi_port_a = 8'h00;
    wire ppi_req_r;
    wire ppi_req_w;
    wire [1:0] pri_slot;
    wire [3:0] pri_slot_num;
    wire [3:0] page_num;

    //----------------------------------------------------------------
    //-- PPI(8255) / primary-slot
    //----------------------------------------------------------------
    assign ppi_req_r = (bus_addr[7:0] == 8'ha8 && bus_iorq_n == 0 && bus_m1_n == 1 && bus_rd_n == 0)? 1:0;
    assign ppi_req_w = (bus_addr[7:0] == 8'ha8 && bus_iorq_n == 0 && bus_m1_n == 1 && bus_wr_n == 0)? 1:0;

    always @ (posedge clk_27m or negedge bus_reset_n) begin
        if ( bus_reset_n == 0)
            ppi_port_a <= 8'h00;
        else begin
            if (ppi_req_w == 1 ) begin
                ppi_port_a <= cpu_dout;
            end
        end
    end

    //expanded slot 3
    reg [7:0] exp_slotx;
    wire [1:0] exp_slotx_page;
    wire [3:0] exp_slotx_num;
    reg exp_slotx_req_r;
    reg exp_slotx_req_w;
    wire xffff;
    reg xffh;
    reg xffl;
    always @ (posedge clk_54m) begin
        xffh <= bus_addr[15:8] == 8'hff;
        xffl <= bus_addr[7:0] == 8'hff;
        exp_slotx_req_w <= ( bus_mreq_n == 0 && bus_wr_n == 0 && xffh == 1 && xffl == 1 && pri_slot_num[SD_SLOT] == 1 ) ? 1: 0;
        exp_slotx_req_r <= ( bus_mreq_n == 0 && bus_rd_n == 0 && xffh == 1 && xffl == 1 && pri_slot_num[SD_SLOT] == 1 ) ? 1: 0;
    end
    //assign xffff = ( bus_addr == 16'hffff ) ? 1 : 0;
    assign xffff = xffh & xffl;

//    assign exp_slotx_req_w = ( bus_mreq_n == 0 && bus_wr_n == 0 && xffff == 1 && pri_slot_num[0] == 1 ) ? 1: 0;
//    assign exp_slotx_req_r = ( bus_mreq_n == 0 && bus_rd_n == 0 && xffff == 1 && pri_slot_num[0] == 1 ) ? 1: 0;

    // slot #3
    always @ (posedge clk_27m or negedge bus_reset_n) begin
        if ( bus_reset_n == 0 )
            exp_slotx <= 8'h00;
        else begin
            if (exp_slotx_req_w == 1 ) begin
                exp_slotx <= cpu_dout;
            end
        end
    end

    // slots decoding
    assign pri_slot = ( bus_addr[15:14] == 2'b00) ? ppi_port_a[1:0] :
                      ( bus_addr[15:14] == 2'b01) ? ppi_port_a[3:2] :
                      ( bus_addr[15:14] == 2'b10) ? ppi_port_a[5:4] :
                                             ppi_port_a[7:6];

    assign pri_slot_num = ( pri_slot == 2'b00 ) ? 4'b0001 :
                          ( pri_slot == 2'b01 ) ? 4'b0010 :
                          ( pri_slot == 2'b10 ) ? 4'b0100 :
                                                  4'b1000;

    assign page_num = ( bus_addr[15:14] == 2'b00) ? 4'b0001 :
                      ( bus_addr[15:14] == 2'b01) ? 4'b0010 :
                      ( bus_addr[15:14] == 2'b10) ? 4'b0100 :
                                                    4'b1000;

    assign exp_slotx_page = ( bus_addr[15:14] == 2'b00) ? exp_slotx[1:0] :
                            ( bus_addr[15:14] == 2'b01) ? exp_slotx[3:2] :
                            ( bus_addr[15:14] == 2'b10) ? exp_slotx[5:4] :
                                                          exp_slotx[7:6];

    assign exp_slotx_num = ( exp_slotx_page == 2'b00 ) ? 4'b0001 :
                           ( exp_slotx_page == 2'b01 ) ? 4'b0010 :
                           ( exp_slotx_page == 2'b10 ) ? 4'b0100 :
                                                         4'b1000;

//    reg slot0_req_r;
//    wire slot0_req_w;
//    wire slot3_req_r;
//    wire slot3_req_w;
//    always @ (posedge clk_27m) begin
//        slot0_req_r <= ( bus_mreq_n == 0 && bus_rd_n == 0 && pri_slot_num[0] == 1 ) ? 1 : 0;
//    end
//`ifdef ENABLE_BIOS
//    assign slot0_req_w = ( bus_mreq_n == 0 && bus_wr_n == 0 && pri_slot_num[0] == 1 ) ? 1 : 0;
//`endif
//    assign slot3_req_r = ( bus_mreq_n == 0 && bus_rd_n == 0 && pri_slot_num[3] == 1 ) ? 1 : 0;
//    assign slot3_req_w = ( bus_mreq_n == 0 && bus_wr_n == 0 && pri_slot_num[3] == 1 ) ? 1 : 0;

    reg slotx_req_r;
    always @ (posedge clk_54m) begin
        slotx_req_r <= ( bus_mreq_n == 0 && bus_rd_n == 0 && pri_slot_num[SD_SLOT] == 1 ) ? 1 : 0;
    end

`ifdef ENABLE_BIOS
    //bios
    reg bios_req;
    wire [7:0] bios_dout;
    //wire [7:0] bios_int_dout;
    //wire [7:0] key_bra_dout;
    //wire keyboard_area;
    always @ (posedge clk_27m) begin
        bios_req <= ( bus_mreq_n == 0 && bus_rd_n == 0 && pri_slot_num[0] == 1 ) ? 1 : 0;
    end
    //assign bios_req = ( bus_addr[15] == 0 && bus_mreq_n == 0 && bus_rd_n == 0 && pri_slot_num[0] == 1 ) ? 1 : 0;
    //assign keyboard_area = ( bus_addr[14:8] == 7'hd || bus_addr[14:8] == 7'he ) ? 1 : 0;

    bios_msx2p bios1 (
        .address (bus_addr[14:0]),
        .clock (clk_27m),
        .data (8'h00),
        .wren (0),
        .q (bios_dout)
    );

//    keyboard_bra key_bra1 (
//        .address ( { ~bus_addr[8], bus_addr[7:0] } ),
//        .clock (clk_108m),
//        .data (8'h00),
//        .wren (0),
//        .q (key_bra_dout)
//    );
//    assign bios_dout = ( config_keyboard != 2'b01 || keyboard_area == 0 ) ? bios_int_dout : key_bra_dout;

    //subrom
    reg subrom_req;
    wire [7:0] subrom_dout;
    always @ (posedge clk_27m) begin
        subrom_req <= ( bus_mreq_n == 0 && bus_rd_n == 0 && pri_slot_num[SD_SLOT] == 1 && page_num[0] == 1 && exp_slotx_num[1] == 1 ) ? 1 : 0;
    end
    //assign subrom_req = ( bus_mreq_n == 0 && bus_rd_n == 0 && pri_slot_num[2] == 1 && page_num[0] == 1 ) ? 1 : 0;

    subrom_msx2p subrom1 (
        .address (bus_addr[13:0]),
        .clock (clk_27m),
        .data (8'h00),
        .wren (0),
        .q (subrom_dout)
    );

    //msx logo
    reg msx_logo_req;
    wire [7:0] msx_logo_dout;
    always @ (posedge clk_27m) begin
        msx_logo_req <= ( bus_mreq_n == 0 && bus_rd_n == 0 && page_num[1] == 1 && pri_slot_num[SD_SLOT] == 1 && exp_slotx_num[1] == 1 ) ? 1 : 0;
    end
    //assign msx_logo_req = ( bus_mreq_n == 0 && bus_rd_n == 0 && pri_slot_num[2] == 1 && page_num[1] == 1 ) ? 1 : 0;

    logo_fm logo1 (
        .address (bus_addr[13:0]),
        .clock (clk_27m),
        .data (8'h00),
        .wren (0),
        .q (msx_logo_dout)
    );

`else

    wire bios_req;
    wire [7:0] bios_dout;
    wire subrom_req;
    wire [7:0] subrom_dout
    wire msx_logo_req;
    wire [7:0] msx_logo_dout;

`endif

    //rtc
    wire rtc_req_r;
    wire rtc_req_w;
    wire [7:0] rtc_dout;
    assign rtc_req_w = (bus_addr[7:1] == 7'b1011010 && bus_iorq_n == 0 && bus_m1_n == 1 && bus_wr_n == 0)? 1 : 0; // I/O:B4-B5h   / RTC
    assign rtc_req_r = (bus_addr[7:1] == 7'b1011010 && bus_iorq_n == 0 && bus_m1_n == 1 && bus_rd_n == 0)? 1 : 0; // I/O:B4-B5h   / RTC

    rtc rtc1(
        .clk21m(clk_27m),
        .reset(0),
        .clkena(1),
        .req(rtc_req_w | rtc_req_r),
        .ack(),
        .wrt(rtc_req_w),
        .adr(bus_addr),
        .dbi(rtc_dout),
        .dbo(cpu_dout)
    );

    //vdp
	wire vdp_csw_n; //VDP write request
	wire vdp_csr_n; //VDP read request	
    wire [7:0] vdp_dout;
    wire vdp_int;
    wire WeVdp_n;
    wire [16:0] VdpAdr;
    wire [15:0] VrmDbi;
    wire [7:0] VrmDbo;
    wire VideoDHClk;
    wire VideoDLClk;
    assign vdp_csw_n = (bus_addr[7:2] == 6'b100110 && bus_iorq_n == 0 && bus_m1_n == 1 && bus_wr_n == 0)? 0:1; // I/O:98-9Bh   / VDP (V9938/V9958)
    assign vdp_csr_n = (bus_addr[7:2] == 6'b100110 && bus_iorq_n == 0 && bus_m1_n == 1 && bus_rd_n == 0)? 0:1; // I/O:98-9Bh   / VDP (V9938/V9958)

    v9958_top vdp4 (
        .clk (clk_27m),
        .s1 (0),
        .clk_50 (0),
        .clk_125 (0),

    `ifdef ENABLE_V9958
        .reset_n (bus_reset_n ),
    `else
        .reset_n (0),
    `endif
        .mode    (bus_addr[1:0]),
        .csw_n   (vdp_csw_n),
        .csr_n   (vdp_csr_n),

        .int_n   (vdp_int),
        .gromclk (),
        .cpuclk  (),
        .cdi     (vdp_dout),
        .cdo     (cpu_dout),

        .audio_sample   (audio_sample),

        .adc_clk  (),
        .adc_cs   (),
        .adc_mosi (),
        .adc_miso (0),

        .maxspr_n    (1),
    `ifdef ENABLE_SCAN_LINES
        .scanlin_n   (~config_enable_scanlines),
    `else
        .scanlin_n   (1),
    `endif
        .gromclk_ena_n (1),
        .cpuclk_ena_n  (1),

        .WeVdp_n(WeVdp_n),
        .VdpAdr(VdpAdr),
        .VrmDbi(VrmDbi2),
        .VrmDbo(VrmDbo),

        .VideoDHClk(VideoDHClk),
        .VideoDLClk(VideoDLClk),

        .tmds_clk_p    (clk_p),
        .tmds_clk_n    (clk_n),
        .tmds_data_p   (data_p),
        .tmds_data_n   (data_n)
    );

`ifdef ENABLE_MAPPER
    //mapper
    wire mapper_read;
    wire mapper_write;
    wire mapper_req;
    reg mapper_req3;
    reg mapper_req12;
    reg [7:0] mapper_dout;
    wire [21:0] mapper_addr;
    reg [7:0] mapper_reg0;
    reg [7:0] mapper_reg1;
    reg [7:0] mapper_reg2;
    reg [7:0] mapper_reg3;
    wire mapper_reg_write;

    assign mapper_addr = (bus_addr [15:14] == 2'b00 ) ? { mapper_reg0, bus_addr[13:0] } :
                         (bus_addr [15:14] == 2'b01 ) ? { mapper_reg1, bus_addr[13:0] } :
                         (bus_addr [15:14] == 2'b10 ) ? { mapper_reg2, bus_addr[13:0] } :
                                                        { mapper_reg3, bus_addr[13:0] };

    always @ (posedge clk_54m) begin
        mapper_req3 <= ( bus_rfsh_n == 1 && config_enable_mapper3 == 1 && bus_mreq_n == 0 && (bus_rd_n == 0 || bus_wr_n == 0 ) && pri_slot_num[SD_SLOT] == 1 && exp_slotx_num[0] == 1 && xffff == 0) ? 1 : 0;
        mapper_req12 <= ( config_enable_mapper12 == 1 && bus_mreq_n == 0 && (bus_rd_n == 0 || bus_wr_n == 0 ) && pri_slot == config_mapper_slot ) ? 1 : 0;
    end
    assign mapper_req = mapper_req3 | mapper_req12;
    assign mapper_read = mapper_req & ~bus_rd_n;
    assign mapper_write = mapper_req & ~bus_wr_n;
    assign mapper_reg_write = ( (bus_iorq_n == 0 && bus_m1_n == 1 && bus_wr_n == 0) && (bus_addr [7:2] == 6'b111111) )?1:0;

    always @(posedge clk_27m or negedge bus_reset_n) begin
        if (bus_reset_n == 0) begin
            mapper_reg0	<= 8'b00000011;
            mapper_reg1	<= 8'b00000010;
            mapper_reg2	<= 8'b00000001;
            mapper_reg3	<= 8'b00000000;
        end
        else if (mapper_reg_write == 1) begin
            case (bus_addr[1:0])
`ifndef SDRAM_32
                2'b00: mapper_reg0 <= { 1'b0, cpu_dout[6:0] };
                2'b01: mapper_reg1 <= { 1'b0, cpu_dout[6:0] };
                2'b10: mapper_reg2 <= { 1'b0, cpu_dout[6:0] };
                2'b11: mapper_reg3 <= { 1'b0, cpu_dout[6:0] };
`else
                2'b00: mapper_reg0 <= cpu_dout[7:0];
                2'b01: mapper_reg1 <= cpu_dout[7:0];
                2'b10: mapper_reg2 <= cpu_dout[7:0];
                2'b11: mapper_reg3 <= cpu_dout[7:0];
`endif
            endcase
        end
    end
`else
    wire mapper_read;
    wire mapper_write;
    wire mapper_req;
    reg [7:0] mapper_dout;
    wire [21:0] mapper_addr;
    assign mapper_read = 0;
    assign mapper_write = 0;
    assign mapper_addr = 22'd0;
`endif

reg [15:0] VrmDbi2;
reg [7:0] megaram_dout;

// Phase5: extended-memory SD-RAM request (MSX_T80_24bit化_実装手順_V2
// section 7 "Phase 5"). When the current data access has a non-zero
// physical bank (= A_Bank straight through, see mmu_physical_bank above),
// route the bus cycle straight to the flat 24bit SD-RAM window
// (memory_ctrl's pre-existing cpu_sdram_* port group) instead of the
// legacy MSX slot/BIOS/mapper decode below. Legacy M0-only MSX software
// always has mmu_physical_bank = 00h (Phase3 forces A_Bank = 00h outside
// register-indirect M1/M2 accesses), so this path is never taken by
// existing software and the legacy decode is unaffected.
//
// Per doc/jpn/SDRAMメモリマップ.md, 0x000000-0x5FFFFF is already occupied by
// the legacy Memory Mapper (0x000000-0x3FFFFF) and MegaRAM/SCC
// (0x400000-0x5FFFFF), and 0x600000-0x63FFFF is reserved for VDP VRAM
// headroom. The only untouched region is 0x640000-0x7FFFFF (~1.75MB), so
// this new client is based at CPU_SDRAM_BASE and limited to physical
// banks 01h-1Bh (27 x 64KB = 0x1B0000, leaving the first 64KB of the free
// region, 0x640000-0x64FFFF, spare) to guarantee it can never alias or
// overflow into an existing client's region. physical bank 00h is always
// excluded (legacy alias, enforced below by cpu_sdram_bank_in_range);
// banks above 1Bh are simply not routed here yet (an access with such a
// bank reads back 8'hFF, same as any other unmapped region, and writes
// are silently dropped) until a larger dedicated SD-RAM allocation is
// carved out.
localparam [23:0] CPU_SDRAM_BASE = 24'h640000;
localparam [7:0]  CPU_SDRAM_BANK_MAX = 8'h1B;

// v8 fix (2026-10-17, see doc/jpn/PUSH24_POP24_bank境界またぎバグ_調査
// レポート.md "追記4"/"追記5" for the full investigation log that led
// here, including a cycle-accurate GHDL reproduction testbench,
// fpga/G80A/test/tb_hw_push24_bank_boundary_timing.vhd, that this exact
// design was validated against across a wide sweep of video-bandwidth-
// arbitration timings before being ported here). v1-v4 (all now
// superseded) asserted cpu_sdram_wait_n REACTIVELY, off bus_mreq_n/
// bus_rd_n/bus_wr_n becoming active - but direct simulation tracing
// proved this can never be observed in time: fpga/G80A/g80a.vhd asserts
// those same bus signals AND samples WAIT_n into its internal Wait_s on
// the EXACT SAME clk_falling edge (both are g80a.vhd processes
// triggered by that one edge), so a WAIT asserted only in REACTION to
// those signals cannot possibly be seen by that SAME edge's Wait_s
// sample (ordinary synchronous-logic causality: a register cannot
// observe another register's output changing as a RESULT of the very
// same clock edge) - WAIT was being structurally, unavoidably missed
// for the specific M-cycle it mattered for, no matter how long it was
// held afterward (which is why three different "hold it more
// carefully/longer" fix attempts, v1-v4, all failed identically).
//
// v8 instead asserts cpu_sdram_wait_n EARLY, off T80's own "update_addr"
// output (already wired through as the "update_addr" wire above,
// unchanged from existing usage elsewhere in this file): it pulses for
// one CEN(clk_enable)-gated T80-internal cycle at T_Res of EVERY
// M-cycle - the SAME moment A_Bank_r (hence mmu_physical_bank) is set
// up for the UPCOMING M-cycle, a full clk_enable-to-clk_falling gap
// BEFORE that upcoming M-cycle's own bus signals ever assert. Sampling
// mmu_physical_bank one real clk_54m cycle after update_addr's rising
// edge (to let A_Bank_r settle) and asserting WAIT immediately if it is
// non-zero gives a full inter-M-cycle gap of lead time, with no
// same-edge race.
//
// update_addr is NOT a narrow single-cycle pulse - once set it HOLDS
// high across every real clk_54m cycle until the NEXT CEN tick (up to a
// full virtual-clock period), so detecting "a NEW T_Res event" requires
// a genuine 2-stage edge detector (update_addr_prev/update_addr_prev2
// below) - a naive single-stage "was high last cycle" check re-triggers
// spuriously on every cycle update_addr happens to still be held high,
// which (during this investigation) caused a DIFFERENT deadlock: WAIT
// released correctly, then immediately got spuriously re-asserted for
// the SAME, not-yet-advanced M-cycle, before memory_ctrl's sdram_seq
// (parked in its own "return to idle" state, itself waiting for
// cpu_sdram_req to genuinely drop once the CPU truly moves on) ever got
// a chance to restart - a permanent deadlock, confirmed and fixed via
// the same GHDL testbench referenced above.
reg update_addr_prev;
reg update_addr_prev2;

localparam [1:0] WS_IDLE = 2'd0, WS_ARMED = 2'd1, WS_WAITING_DONE = 2'd2;
reg [1:0] wait_state;
// v9: update_addr also starts internal (NoRead) M-cycles and interrupt
// acknowledge cycles, whose bank can be a non-zero PC bank in M2 (e.g. the
// JR/DJNZ displacement-add cycle) but which never assert MREQ. Memory
// cycles assert MREQ/RD at the first CPU falling edge and WR at the second;
// if MREQ is still inactive by the third, release WAIT instead of waiting
// forever for a request that cannot arrive.
reg [1:0] wait_armed_falls;

wire cpu_sdram_bank_in_range = (mmu_physical_bank != 8'h00) && (mmu_physical_bank <= CPU_SDRAM_BANK_MAX);

// cpu_sdram_active is PURELY combinational (no register delay) - once
// wait_state reaches WS_ARMED (asserted early, well before this goes
// high), this is what tells us the real bus request for THIS M-cycle
// has genuinely arrived.
wire cpu_sdram_active = ( cpu_sdram_bank_in_range && extended_mreq_n == 0 &&
                          (bus_rd_n == 0 || bus_wr_n == 0) && bus_rfsh_n == 1 );
// Publish only after WS_ARMED has latched this cycle's address/write flag.
wire cpu_sdram_req = cpu_sdram_active && (wait_state == WS_WAITING_DONE);

reg [23:0] cpu_sdram_addr_r;
reg cpu_sdram_write_r;
wire cpu_sdram_write;
wire [23:0] cpu_sdram_addr;
wire [7:0] cpu_sdram_dout;
wire cpu_sdram_busy;
wire cpu_sdram_done;

// No MMU in this build, so there is no per-bank write-protection
// attribute to gate against (see the MMU24 removal note above): any
// in-range bank is both readable and writable.
assign cpu_sdram_write = cpu_sdram_req & cpu_sdram_write_r;
assign cpu_sdram_addr = cpu_sdram_addr_r;

reg cpu_sdram_wait_n;

always @ (posedge clk_54m) begin
    if (bus_reset_n == 0) begin
        cpu_sdram_wait_n <= 1;
        wait_state <= WS_IDLE;
        wait_armed_falls <= 2'd0;
        update_addr_prev <= 0;
        update_addr_prev2 <= 0;
        cpu_sdram_addr_r <= 24'd0;
        cpu_sdram_write_r <= 0;
    end
    else begin
        update_addr_prev <= update_addr;
        update_addr_prev2 <= update_addr_prev;

        case (wait_state)
            WS_IDLE: begin
                if (update_addr_prev == 1 && update_addr_prev2 == 0 &&
                    mmu_physical_bank != 8'h00 && mmu_physical_bank <= CPU_SDRAM_BANK_MAX) begin
                    // update_addr had a GENUINE 0->1 transition one real
                    // clk_54m cycle ago (the 2-stage edge detector - see
                    // the block comment above for why a single-stage
                    // check is not sufficient) giving mmu_physical_bank
                    // a full cycle to settle to the NEW M-cycle's bank
                    // before we read it, and that upcoming M-cycle needs
                    // the extended SD-RAM window - assert WAIT now, well
                    // ahead of this M-cycle's own bus signals.
                    cpu_sdram_wait_n <= 0;
                    wait_armed_falls <= 2'd0;
                    wait_state <= WS_ARMED;
                end
            end
            WS_ARMED: begin
                if (clk_falling_3m6_54 == 1 && wait_armed_falls != 2'd3)
                    wait_armed_falls <= wait_armed_falls + 2'd1;

                if (cpu_sdram_active == 1) begin
                    // The real bus request for THIS M-cycle has now
                    // genuinely asserted (extended_mreq_n/bus_rd_n/
                    // bus_wr_n) - latch its address/write-flag (same
                    // rationale as v3's latch: protect against
                    // mmu_physical_bank drifting later) and move on to
                    // waiting for genuine completion.
                    cpu_sdram_addr_r <= CPU_SDRAM_BASE + { mmu_physical_bank, extended_addr[15:0] };
                    cpu_sdram_write_r <= ~bus_wr_n;
                    wait_state <= WS_WAITING_DONE;
                end
                else if (wait_armed_falls == 2'd3 && extended_mreq_n == 1) begin
                    cpu_sdram_wait_n <= 1;
                    wait_state <= WS_IDLE;
                end
            end
            WS_WAITING_DONE: begin
                if (cpu_sdram_done == 1) begin
                    // memory_ctrl's unambiguous "data genuinely
                    // committed" pulse - see cpu_sdram_done's port
                    // declaration comment in fpga/src/memory.v. Release
                    // the CPU and return to idle; the NEXT update_addr
                    // 0->1 transition (which cannot occur until T80 has
                    // genuinely advanced past THIS M-cycle) is what
                    // re-arms.
                    cpu_sdram_wait_n <= 1;
                    wait_state <= WS_IDLE;
                end
            end
            default: wait_state <= WS_IDLE;
        endcase
    end
end

// memory_bus blocks all nonzero banks from the legacy MSX memory decoders,
// including banks outside the implemented SDRAM range. The arbiter's CPU
// priority remains in place, but is not relied on to prevent slot side effects.

memory_ctrl mem1 (
    .clk_27m(clk_54m),
    .clk_108m(clk_108m),
    .bus_reset_n(bus_reset_n ),
    .video_dhclk(VideoDHClk),
    .video_dlclk(VideoDLClk),

    .cpu_sdram_req(cpu_sdram_req),
    .cpu_sdram_write(cpu_sdram_write),
    .cpu_sdram_addr(cpu_sdram_addr),

    .mapper_din(cpu_dout),
    .mapper_req(mapper_req),
    .mapper_write(mapper_write),
    .megaram_req(megaram_req),
    .megaram_write(megaram_wrt),
    .mapper_addr(mapper_addr),
    .megaram_addr(megaram_addr),
    .vram_din(VrmDbo),
    .vram_write(~WeVdp_n),
    .vram_addr(VdpAdr),
    .bus_rfsh_n(bus_rfsh_n),

    .cpu_sdram_dout(cpu_sdram_dout),
    .cpu_sdram_busy(cpu_sdram_busy),
    .cpu_sdram_done(cpu_sdram_done),
    .mapper_dout(mapper_dout),
    .megaram_dout(megaram_dout),
    .vram_dout(VrmDbi2),

    .O_sdram_clk(O_sdram_clk),
    .O_sdram_cke(O_sdram_cke),
    .O_sdram_cs_n(O_sdram_cs_n),
    .O_sdram_cas_n(O_sdram_cas_n),
    .O_sdram_ras_n(O_sdram_ras_n),
    .O_sdram_wen_n(O_sdram_wen_n),
    .IO_sdram_dq(IO_sdram_dq),
    .O_sdram_addr(O_sdram_addr),
    .O_sdram_ba(O_sdram_ba),
    .O_sdram_dqm(O_sdram_dqm)
);




`ifdef ENABLE_SOUND

    //YM219 PSG
    wire psgBdir;
    wire psgBc1;
    wire iorq_wr_n;
    wire iorq_rd_n;
    wire [7:0] psg_dout;
    wire [7:0] psgSound1;
    wire [7:0] psgPA;
    wire [7:0] psgPB;
    reg clk_1m8;
    assign iorq_wr_n = bus_iorq_n | bus_wr_n;
    assign iorq_rd_n = bus_iorq_n | bus_rd_n;
    assign psgBdir = ( bus_addr[7:3]== 5'b10100 && iorq_wr_n == 0 && bus_addr[1]== 0 ) ?  1 : 0; // I/O:A0-A2h / PSG(AY-3-8910) bdir = 1 when writing to &HA0-&Ha1
    assign psgBc1 = ( bus_addr[7:3]== 5'b10100 && ((iorq_rd_n==0 && bus_addr[1]== 1) || (bus_addr[1]==0 && iorq_wr_n==0 && bus_addr[0]==0))) ? 1 : 0; // I/O:A0-A2h / PSG(AY-3-8910) bc1 = 1 when writing A0 or reading A2
`ifdef USE_DOCK_JOISTICK
    assign psgPA = dock_psg_ioa;
`else
    assign psgPA = 8'h00;
`endif
    wire [7:0] psgPB;

    wire clk_enable_1m8;
    reg clk_1m8_prev;
    always @ (posedge clk_27m) begin
        if (clk_enable_3m6_27) begin
            clk_1m8 <= ~clk_1m8;
        end
    end
    assign clk_enable_1m8 = (clk_enable_3m6_27 == 1 && clk_1m8 == 1);

    YM2149 psg1 (
        .I_DA(cpu_dout),
        .O_DA(psg_dout),
        .O_DA_OE_L(),
        .I_A9_L(0),
        .I_A8(1),
        .I_BDIR(psgBdir),
        .I_BC2(1),
        .I_BC1(psgBc1),
        .I_SEL_L(1),
        .O_AUDIO(psgSound1),
        .I_IOA(psgPA),
        .O_IOA(),
        .O_IOA_OE_L(),
        .I_IOB(psgPB),
        //.O_IOB(psgPB),
        .O_IOB(psgPB),
        .O_IOB_OE_L(),
        
        .ENA(clk_enable_1m8), // clock enable for higher speed operation
        .RESET_L(bus_reset_n),
        .CLK(clk_27m),
        .clkHigh(clk_27m),
        .debug ()
    );

    wire [7:0] psgSound3;
    psg_filter filter1 (
        .clk_27m (clk_27m),
        .reset (~bus_reset_n),
        .data_in (psgSound1),
        .data_out (psgSound3)
    );

    //opll
    wire opll_req_n; 
    wire [9:0] opll_mo;
    wire [9:0] opll_ro;
    reg [11:0] opll_mix;
    wire [15:0] jt2413_wav;

    assign opll_req_n = ( bus_iorq_n == 1'b0 && bus_addr[7:1] == 7'b0111110  &&  bus_wr_n == 1'b0 )  ? 1'b0 : 1'b1;    // I/O:7C-7Dh   / OPLL (YM2413)
  
    jt2413 opll(
        .rst (~bus_reset_n),        // rst should be at least 6 clk&cen cycles long
        .clk (clk_27m),        // CPU clock
        .cen (clk_enable_3m6_27),        // optional clock enable, if not needed leave as 1'b1
        .din (cpu_dout),
        .addr (bus_addr[0]),
        .cs_n (opll_req_n),
        .wr_n (1'b0),
        // combined output
        .snd (jt2413_wav),
        .sample   ( )
    ); 

    //scc & ghost scc
    wire [14:0] scc_wav;
    wire [7:0] scc_dout;
    wire scc_req;
    reg scc_req3;
    wire scc_req3_r;
    reg scc_req12;

    wire scc_wrt;
    
    reg x98h;
    always @ (posedge clk_27m) begin
        x98h <= ( bus_addr[15:8] == 8'h98 ) ? 1 : 0;
    end

    reg [7:0] scc_bank2;
    reg scc_enable_req3;
    reg scc_enable_req12;
    wire scc_enable_req;
    always @ (posedge clk_27m) begin
        scc_enable_req3 <= ( bus_addr[15:11] == 5'b10010 && bus_mreq_n == 0 && bus_wr_n == 0 && pri_slot_num[SD_SLOT] == 1 && exp_slotx_num[3] == 1 ) ? 1 : 0;
        scc_enable_req12 <= ( config_enable_megaram12 == 1 && bus_addr[15:11] == 5'b10010 && bus_mreq_n == 0 && bus_wr_n == 0 && pri_slot == config_megaram_slot ) ? 1 : 0;
    end
    assign scc_enable_req = scc_enable_req3 | scc_enable_req12;

    always @ (posedge clk_27m or negedge bus_reset_n) begin
        if ( bus_reset_n == 0)
            scc_bank2 <= 8'h00;
        else begin
            if (scc_enable_req == 1 ) begin
                scc_bank2 <= cpu_dout;
            end
        end
    end

    wire scc_enable;
    assign scc_enable = ( scc_bank2 == 8'h3f ) ? 1 : 0;

    always @ (posedge clk_27m) begin
        scc_req3 <= ( config_enable_megaram3 == 1 && scc_enable == 1 && x98h == 1 && bus_mreq_n == 0 && (bus_wr_n == 0 || bus_rd_n == 0 ) && pri_slot == config_megaram_slot && exp_slotx_num[3] == 1  ) ? 1 : 0;
        scc_req12 <= ( config_enable_megaram12 == 1 && scc_sound_disable == 0 && scc_enable == 1 && x98h == 1 && bus_mreq_n == 0 && (bus_wr_n == 0 || bus_rd_n == 0 ) && pri_slot == config_megaram_slot ) ? 1 : 0;
    end
    assign scc_req = scc_req3 | scc_req12;
    assign scc_req3_r = ( scc_req3 == 1 && bus_rd_n == 0 ) ? 1 : 0;
    assign scc_wrt = ( scc_req == 1 && bus_wr_n == 0 ) ? 1 : 0;

    scc_wave2 SccCh (
        .clk21m (clk_27m),
        .reset (~bus_reset_n),
        .clkena (clk_enable_3m6_27),
        .req ( scc_req),
        .ack (),
        .wrt (scc_wrt),
        .adr (bus_addr[7:0]),
        .dbi (scc_dout),
        .dbo (cpu_dout),
        .wave (scc_wav)
    );

    reg scc2_req3;
    reg scc2_req12;
    wire scc2_req;
    wire scc2_req_r;
    wire scc2_wrt;
    wire [7:0] scc2_dout;
    wire [14:0] scc2_wav;
    wire megaram_req;
    wire megaram_wrt;
    wire [20:0] megaram_addr;
    wire megaram_enabled;

    always @ (posedge clk_54m) begin
        scc2_req3 <= ( config_enable_ghost_scc == 0 && config_enable_megaram3 == 1 && bus_mreq_n == 0 && (bus_rd_n == 0 || bus_wr_n == 0 ) && pri_slot == config_megaram_slot && exp_slotx_num[3] == 1  && xffff == 0) ? 1 : 0;
        scc2_req12 <= ( config_enable_ghost_scc == 0 && config_enable_megaram12 == 1 && bus_mreq_n == 0 && (bus_rd_n == 0 || bus_wr_n == 0 ) && pri_slot == config_megaram_slot ) ? 1 : 0;
        //scc2_req <= ( bus_mreq_n == 0 && (bus_rd_n == 0 || bus_wr_n == 0 ) && pri_slot_num[2] == 1 ) ? 1 : 0;
    end
    assign scc2_req = scc2_req3 | scc2_req12;
    assign scc2_req_r = ( scc2_req == 1 && bus_rd_n == 0 ) ? 1 : 0;
    assign scc2_wrt = ( scc2_req == 1 && bus_wr_n == 0 ) ? 1 : 0;

    wire [1:0] map_sel;
    wire map_linear;
    wire scc_sound_disable;
    assign map_sel = Slot2Mode;
    assign map_linear = iSlt2_linear;

    megaram_scc megaram1 (
        .clk_27m (clk_54m),
        .bus_reset_n (bus_reset_n),
        .bus_addr (bus_addr),
        .cpu_dout (cpu_dout),
        .bus_rd_n (bus_rd_n),
        .bus_wr_n (bus_wr_n),
        .scc_req (scc2_req),
        .scc_wrt (scc2_wrt),
        .map_sel (map_sel),
        .map_linear (map_linear),

        .megaram_req (megaram_req),
        .megaram_wrt (megaram_wrt), 
        .megaram_addr (megaram_addr),
        .scc_sound_disable (scc_sound_disable)
    );


    //mixer
    reg [23:0] fm_wav;
    reg [16:0] fm_mix;
    reg [14:0] scc_wav2;
	reg [15:0] audio_sample;

    always @ (posedge clk_27m) begin
        if (clk_enable_3m6_27 == 1 ) begin
            if (map_sel[0] == 0)
                audio_sample <= { 2'b0 , psgSound3 , 6'b000000 } + { scc_wav, 1'b0 } + jt2413_wav;
            else
                audio_sample <= { 2'b0 , psgSound3 , 6'b000000 } + jt2413_wav;
        end
    end

`else

    wire scc2_req;
    wire [14:0] scc2_wav;
    wire megaram_req;
    wire [20:0] megaram_addr;
    wire megaram_enabled;
    wire [15:0] audio_sample;
    wire megaram_wrt;

`endif


`ifdef ENABLE_CONFIG
    //config
    reg [7:0] config0_ff = 8'h00;
    reg [7:0] config1_ff = 8'hfb;
    reg [7:0] config1_temp_ff;
    reg [7:0] config2_ff = 8'h07;
    reg [7:0] config2_temp_ff;
    reg [1:0] config_mapper_slot_ff = 2'b11;
    reg [1:0] config_megaram_slot_ff = 2'b11;
    reg [1:0] config_sdcard_slot_ff = 2'b11;
    reg config_enable_mapper3;
    reg config_enable_mapper12;
    wire config_enable_megaram;
    wire config_enable_megaram3;
    wire config_enable_megaram12;
    wire config_enable_ghost_scc;
    reg config_enable_sdcard;
    wire config_enable_wait;
    reg config_reset_ff;
    reg config_update;
    wire config_enable_scanlines;
    wire [1:0] config_mapper_slot;
    wire [1:0] config_megaram_slot;
    wire [1:0] config_sdcard_slot;
    wire [1:0] config_keyboard;
    wire config0_req;
    wire config1_req;
    wire config2_req;
    wire config_reset;
    wire config_ok;
    wire [7:0] config_dout;
    wire config_req;

    always @ (posedge clk_27m) begin
        config_reset_ff <= 0;
        config_update <= 0;
        if (clk_enable_3m6_27 == 1 ) begin
            if (config0_req == 1 ) begin
                config0_ff <= ~cpu_dout;
            end

            if (config1_req == 1 ) begin
                config_update <= 1;
                config1_temp_ff <= cpu_dout;
            end
            if (config2_req == 1 ) begin
                config_update <= 1;
                config2_temp_ff <= cpu_dout[6:0];
                if ( cpu_dout[7] == 1) begin
                    config_reset_ff <= 1;
                end
            end
        end
    end

    reg [2:0] ocm_slot2_prev; //bit2 = linear ,bits 1,0 = mode
    reg ocm_update;
    always @ (posedge clk_27m) begin
        ocm_update <= 0;
        if ( { iSlt2_linear, Slot2Mode } != ocm_slot2_prev ) begin
            ocm_update <= 1;
        end
    end

    always @ (posedge clk_27m) begin
        if (config_update == 1) begin
            config1_ff <= config1_temp_ff;
            config2_ff <= config2_temp_ff;
        end
        if (ocm_update == 1) begin
            config1_ff[7:6] <= 2'b10;
            config1_ff[1] <= 1;
            ocm_slot2_prev <= { iSlt2_linear, Slot2Mode };
        end
    end

    monostable mono (
        .pulse_in(config_reset_ff),
        .clock(clk_27m),
        .pulse_out(config_reset)
    );

    assign config_ok = (config0_ff == 8'hb7) ? 1 : 0;
    assign config0_req = (bus_addr[7:0] == 8'h40 && bus_iorq_n == 0 && bus_m1_n == 1 && bus_wr_n == 0)? 1:0;
    assign config1_req = (config_ok == 1 && bus_addr[7:0] == 8'h41 && bus_iorq_n == 0 && bus_m1_n == 1 && bus_wr_n == 0)? 1:0;
    assign config2_req = (config_ok == 1 && bus_addr[7:0] == 8'h42 && bus_iorq_n == 0 && bus_m1_n == 1 && bus_wr_n == 0)? 1:0;
    assign config_enable_scanlines = config1_ff[3];
    //assign config_keyboard = config2_ff[4:3];
    assign config_enable_wait = config2_ff[3];
    assign config_req = (bus_addr[7:4] == 4'h4 && bus_iorq_n == 0 && bus_m1_n == 1 && bus_rd_n == 0)? 1:0;
    assign config_dout = ( bus_addr[3:0] == 4'h0 ) ? config0_ff :
                         ( bus_addr[3:0] == 4'h1 ) ? config1_ff :
                         ( bus_addr[3:0] == 4'h2 ) ? config2_ff : 8'hff;


    always_latch begin
        if (~bus_reset_n) begin
            config_mapper_slot_ff <= config1_ff[5:4];
            //config_megaram_slot_ff <= config1_ff[7:6];
            config_enable_mapper3 <= (config1_ff[0] == 1 && config1_ff[5:4] == 2'b11);
            config_enable_mapper12 <= (config1_ff[0] == 1 && config1_ff[5:4] != 2'b11);
            config_enable_sdcard <= config2_ff[0];
            config_sdcard_slot_ff <= config2_ff[2:1];
        end
    end
    assign config_mapper_slot = config_mapper_slot_ff;
    assign config_megaram_slot = config1_ff[7:6];;
    assign config_sdcard_slot = config_sdcard_slot_ff;
    assign config_enable_megaram = config1_ff[1];
    assign config_enable_megaram3 = (config1_ff[1] == 1 && config1_ff[7:6] == 2'b11);
    assign config_enable_megaram12 = (config1_ff[1] == 1 && config1_ff[7:6] != 2'b11 );
    assign config_enable_ghost_scc = config1_ff[2];

`else

    wire config_enable_mapper3;
    wire config_enable_mapper12;
    wire config_enable_megaram;
    wire config_enable_megaram3;
    wire config_enable_megaram12;
    wire config_enable_ghost_scc;
    wire config_enable_sdcard;
    wire config_enable_scanlines;
    wire [1:0] config_mapper_slot;
    wire [1:0] config_megaram_slot;
    wire [1:0] config_sdcard_slot;
    wire config_reset;
    wire config_enable_wait;
    assign config_enable_mapper3 = 1;
    assign config_enable_mapper12 = 0;
    assign config_enable_megaram = 1;
    assign config_enable_megaram3 = 1;
    assign config_enable_megaram12 = 0;
    assign config_enable_ghost_scc = 0;
    assign config_enable_sdcard = 0;
    assign config_enable_scanlines = 1;
    assign config_mapper_slot = 2'b11;
    assign config_megaram_slot = 2'b11;
    assign config_sdcard_slot= 2'b11;
    assign config_reset = 0;
    assign config_enable_wait = 0;

`endif

`ifdef ENABLE_SDCARD

    //megarom
    reg megarom_req;
    wire [24:0] megarom_addr;
    reg [2:0] megarom_page_ff;
    reg megarom_page_req;
    wire [2:0] megarom_page;

    always @ (posedge clk_54m) begin
        megarom_req <=     ( config_enable_sdcard == 1 && bus_mreq_n == 0 && bus_rfsh_n == 1 && bus_rd_n == 0 && pri_slot_num[SD_SLOT] == 1 && exp_slotx_num[2] == 1 && (page_num[1] == 1 || page_num[2] == 1) ) ? 1 : 0;
        megarom_page_req <= ( bus_mreq_n == 0 && bus_rfsh_n == 1 && bus_wr_n == 0 && pri_slot_num[SD_SLOT] == 1 && exp_slotx_num[2] == 1 && bus_addr == 16'h6000 ) ? 1 : 0;
    end
    assign megarom_page = megarom_page_ff;
    assign megarom_addr = { 8'b00001000, megarom_page, bus_addr[13:0] };

    always @(posedge clk_27m or negedge bus_reset_n) begin
        if (bus_reset_n == 0) begin
           megarom_page_ff <= 3'b0;
        end 
        else begin
            if (bus_clk_3m6_27 == 1) begin
                if (megarom_page_req == 1) begin
                    megarom_page_ff <= cpu_dout[2:0]; // select page
                end
            end
        end
    end

//flash
    reg [23:0] ff_flash_addr = 24'd0;
    reg ff_flash_rd = 0;
    reg ff_flash_terminate = 0;
    reg [7:0] ff_rom_dout;
    reg flash_wait_n;
    wire[7:0] flash_dout;
    wire flash_data_ready;
    wire flash_busy;

    flash # (
        .STARTUP_WAIT(1)
    )
    flash1
    (
        .clk(clk_54m),
        .reset_n(bus_reset_n),
        .SCLK(mspi_sclk),
        .CS(mspi_cs),
        .MISO(mspi_miso),
        .MOSI(mspi_mosi),
        .addr(ff_flash_addr),
        .rd(ff_flash_rd),
        .dout(flash_dout),
        .data_ready(flash_data_ready),
        .busy(flash_busy),
        .terminate(ff_flash_terminate)
    );

    reg [7:0] ff_flash_state = 8'd0;

    localparam STATE_RESET          = 8'd0;
    localparam STATE_READ_START     = 8'd1;
    localparam STATE_READ_WAIT      = 8'd2;
    localparam STATE_READ_LOOP      = 8'd3;
    localparam STATE_IDLE           = 8'd4;

    always @(posedge clk_54m, negedge bus_reset_n) begin
    if (bus_reset_n == 0) begin
        ff_flash_state = STATE_RESET;
        ff_flash_rd <= 0;
        flash_wait_n <= 1;
    end else
        case (ff_flash_state)
            STATE_RESET: begin   // reset
                ff_flash_state <= STATE_READ_START;
                ff_flash_rd <= 0;
                ff_flash_terminate <= 1;
            end
            STATE_READ_START: begin  // start read
                if (flash_busy == 0) begin
                    ff_flash_addr <= 24'h100000;
                    ff_flash_state = STATE_READ_WAIT;
                end
            end
            STATE_READ_WAIT: begin  // start read
                if (megarom_req == 1) begin
                    flash_wait_n <= 0;
                    ff_flash_addr <= megarom_addr ;
                    ff_flash_rd <= 1;
                    ff_flash_terminate <= 0;
                    ff_flash_state = STATE_READ_LOOP;
                end
            end
            STATE_READ_LOOP: begin  // loop read
                if (flash_busy == 0 && ff_flash_rd <= 0) begin
                    ff_rom_dout <= flash_dout; 
                    ff_flash_state <= STATE_IDLE;
                end
                else begin
                    ff_flash_rd <= 0;
                end
            end
            STATE_IDLE: begin  // idle
                flash_wait_n <= 1;
                ff_flash_terminate <= 1;
                if (megarom_req == 0) begin
                    ff_flash_state <= STATE_READ_START;
                end
            end
        endcase
    end


    //sd card
    localparam int SDC_SDATA		=  16'h7C00;		 	// rw: 7C00h-7Dff - sector transfer area
    localparam int SDC_ENABLE  	    =  16'h7E00;		    // wo: 1: enable SDC register, 0: disable
    localparam int SDC_CMD			=  SDC_ENABLE+1; 		// wo: cmd to SDC fpga: 1=sd read, 2=sd write
    localparam int SDC_STATUS		=  SDC_CMD+1;	 		// ro: SDC status bits
    localparam int SDC_SADDR		=  SDC_STATUS+1;	 	// wo: 4 bytes: sector addr for read/write
    localparam int SDC_C_SIZE  	    =  SDC_SADDR+4;			// ro: 3 bytes: device size blocks
    localparam int SDC_C_SIZE_MULT	=  SDC_C_SIZE+3;		// ro: 3 bits size multiplier
    localparam int SDC_RD_BL_LEN	=  SDC_C_SIZE_MULT+1;	// ro: 4 bits block length
    localparam int SDC_CTYPE		=  SDC_RD_BL_LEN+1;		// ro: SDC Card type: 0=unknown, 1=SDv1, 2=SDv2, 3=SDHCv2 
    localparam int SDC_MID		    =  SDC_CTYPE+1;		    // ro: manufacture ID: 8 bits unsigned
    localparam int SDC_OID		    =  SDC_MID+1;		    // ro: oem id: 2 character
    localparam int SDC_PNM		    =  SDC_OID+2;		    // ro: product name: 5 character
    localparam int SDC_PSN		    =  SDC_PNM+5;		    // ro: serial number: 32 bits unsigned
    localparam int SCC_ENABLE       =  16'h7E80;            // wo: enable disable SCC+
    localparam int SDC_END          =  16'h7EFF; 
    
    wire [8:0] sram_addr_w;
    reg ff_sram_we = 0;
    reg [7:0] ff_sram_cdin;
    reg [7:0] ff_sram_cdout;
    //
    reg ff_sd_en = 0;
    reg sram_cs_w;
    wire sram_busreq_w;
    wire [7:0] sram_cd_w;
    
    wire [3:0] sd_card_stat_w;
    wire [1:0] sd_card_type_w;
    reg ff_sd_rstart;
    reg ff_sd_init;
    reg [31:0] ff_sd_sector;
    wire sd_busy_w;
    wire sd_done_w;
    wire sd_outen_w;
    wire [8:0] sd_outaddr_w;
    wire [7:0] sd_outbyte_w;
    reg ff_sd_wstart;
    wire [7:0] sd_inbyte_w;
    
    wire [21:0] sd_c_size_w;
    wire [2:0] sd_c_size_mult_w;
    wire [3:0] sd_read_bl_len_w;
    
    wire [7:0] sd_mid_w;
    wire [15:0] sd_oid_w;
    wire [39:0] sd_pnm_w;
    wire [31:0] sd_psn_w;
    wire sd_crc_error_w;
    wire sd_timeout_error_w;
    //reg ff_scc_enable;
    //wire scc_enable_w;
    //assign scc_enable_w = ff_scc_enable;
    always @ (posedge clk_27m) begin
        sram_cs_w <= config_enable_sdcard == 1 && bus_reset_n && ff_sd_en && bus_iorq_n == 1 && bus_m1_n == 1 && bus_mreq_n == 0 && pri_slot_num[SD_SLOT] == 1 && exp_slotx_num[2] == 1 && ( bus_addr >= SDC_SDATA && bus_addr < SDC_ENABLE) ? 1 : 0;
    end
    assign sram_busreq_w = sram_cs_w && ~bus_rd_n;
    
    dpram#(
        .widthad_a(9),
        .width_a(8)
    ) dpram1 (
        .clock_a(clk_27m),
        .wren_a(bus_clk_3m6_27 && sram_cs_w && ~bus_wr_n),
        .rden_a(bus_clk_3m6_27 && sram_cs_w && ~bus_rd_n),
        .address_a(bus_addr[8:0]),
        .data_a(cpu_dout),
        .q_a(sram_cd_w),
    
        .clock_b(clk_27m),
        .wren_b(ff_sd_rstart && sd_outen_w),
        .rden_b(ff_sd_wstart && sd_outen_w),
        .address_b(sd_outaddr_w),
        .data_b(sd_outbyte_w),
        .q_b(sd_inbyte_w)
    );
    
    sd_reader #(
        .CLK_DIV(3'd2),
        .SIMULATE(0)
    ) sd1 (
        .rstn(bus_reset_n),
        .clk(clk_27m),
        .sdclk(sd_sclk),
        .sdcmd(sd_cmd),
        .sddat0(sd_dat0),                  
        .card_stat(sd_card_stat_w),        // show the sdcard initialize status
        .card_type(sd_card_type_w),        // 0=UNKNOWN    , 1=SDv1    , 2=SDv2  , 3=SDHCv2
        .rstart(ff_sd_rstart), 
        .rsector(ff_sd_sector),
        .rbusy(sd_busy_w),
        .rdone(sd_done_w),
        .outen(sd_outen_w),                // when outen=1, a byte of sector content is read out from outbyte
        .outaddr(sd_outaddr_w),            // outaddr from 0 to 511, because the sector size is 512
        .outbyte(sd_outbyte_w),            // a byte of sector content
        .wstart(ff_sd_wstart), 
        .inbyte(sd_inbyte_w),
        .c_size(sd_c_size_w),
        .c_size_mult(sd_c_size_mult_w),
        .read_bl_len(sd_read_bl_len_w),
        .mid(sd_mid_w),
        .oid(sd_oid_w),
        .pnm(sd_pnm_w),
        .psn(sd_psn_w),
        .crc_error(sd_crc_error_w),
        .timeout_error(sd_timeout_error_w),
        .init(ff_sd_init)
    );
    
    assign sd_dat1 = 1;
    assign sd_dat2 = 1;
    assign sd_dat3 = 1; // Must set sddat1~3 to 1 to avoid SD card from entering SPI mode
    
    
    always @(posedge clk_27m or negedge bus_reset_n) begin
        if (~bus_reset_n) begin
            ff_sd_en <= 0;
        end else begin
            if (config_enable_sdcard == 1 && bus_mreq_n == 0 && pri_slot_num[SD_SLOT] == 1 && exp_slotx_num[2] == 1 && bus_addr == SDC_ENABLE && ~bus_wr_n && bus_iorq_n && bus_m1_n)
                ff_sd_en <= cpu_dout[0];
        end
    end
    
    reg sd_cs_w;
    always @ (posedge clk_27m) begin
        sd_cs_w <= config_enable_sdcard == 1 && bus_reset_n && ff_sd_en && bus_iorq_n && bus_m1_n && bus_mreq_n == 0 && pri_slot_num[SD_SLOT] == 1 && exp_slotx_num[2] == 1 && (bus_addr >= SDC_ENABLE && bus_addr <= SDC_END) ? 1 : 0;
    end
    wire sd_busreq_w;
    assign sd_busreq_w = sd_cs_w && ~bus_rd_n;
    reg [7:0] ff_sd_cd;
    wire [7:0] sd_cd_w;
    assign sd_cd_w = ff_sd_cd;
    
    always @(posedge clk_27m or negedge bus_reset_n) begin
        if (~bus_reset_n) begin
            ff_sd_rstart <= '0;
            ff_sd_wstart <= '0;
            ff_sd_init <= '0;
        end else begin
            if (sd_done_w) begin
                ff_sd_rstart <= '0;
                ff_sd_wstart <= '0;
            end
    
            if (sd_cs_w) begin
                if (~bus_wr_n) begin
                    case(bus_addr) 
                        SDC_CMD: begin
                            ff_sd_rstart <= ff_sd_rstart | cpu_dout[0];
                            ff_sd_wstart <= ff_sd_wstart | cpu_dout[1];
                            ff_sd_init   <= ff_sd_init   | cpu_dout[7];
                            //ff_sms_init  <= ff_sms_init  | cdin_w[7];
                        end
                        SDC_SADDR+0:    ff_sd_sector[ 7: 0] <= cpu_dout;
                        SDC_SADDR+1:    ff_sd_sector[15: 8] <= cpu_dout;
                        SDC_SADDR+2:    ff_sd_sector[23:16] <= cpu_dout;
                        SDC_SADDR+3:    ff_sd_sector[31:24] <= cpu_dout;
                    endcase
                end else
                if (~bus_rd_n) begin
                    case(bus_addr) 
                        SDC_ENABLE:     ff_sd_cd <= { 7'b0, ff_sd_en };
                        SDC_STATUS:     ff_sd_cd <= { sd_busy_w, 5'b0, sd_timeout_error_w, sd_crc_error_w };
                        SDC_C_SIZE+0:   ff_sd_cd <= sd_c_size_w[7:0];
                        SDC_C_SIZE+1:   ff_sd_cd <= sd_c_size_w[15:8];
                        SDC_C_SIZE+2:   ff_sd_cd <= { 2'b0, sd_c_size_w[21:16] };
                        SDC_C_SIZE_MULT:ff_sd_cd <= { 5'b0, sd_c_size_mult_w };
                        SDC_RD_BL_LEN:  ff_sd_cd <= { 4'b0, sd_read_bl_len_w };
                        SDC_CTYPE:      ff_sd_cd <= { 6'b0, sd_card_type_w };
                        SDC_MID:        ff_sd_cd <= sd_mid_w;
                        SDC_OID+0:      ff_sd_cd <= sd_oid_w[7:0];
                        SDC_OID+1:      ff_sd_cd <= sd_oid_w[15:8];
                        SDC_PNM+0:      ff_sd_cd <= sd_pnm_w[7:0];
                        SDC_PNM+1:      ff_sd_cd <= sd_pnm_w[15:8];
                        SDC_PNM+2:      ff_sd_cd <= sd_pnm_w[23:16];
                        SDC_PNM+3:      ff_sd_cd <= sd_pnm_w[31:24];
                        SDC_PNM+4:      ff_sd_cd <= sd_pnm_w[39:32];
                        SDC_PSN+0:      ff_sd_cd <= sd_psn_w[7:0];
                        SDC_PSN+1:      ff_sd_cd <= sd_psn_w[15:8];
                        SDC_PSN+2:      ff_sd_cd <= sd_psn_w[23:16];
                        SDC_PSN+3:      ff_sd_cd <= sd_psn_w[31:24];
                        default:        ff_sd_cd <= '1;
                    endcase
                end
            end
        end
    end

`else

    wire sd_busreq_w;
    wire sram_busreq_w;
    wire megarom_req;
    wire megarom_page_req;
    wire sram_cs_w;
    wire sd_cs_w;

`endif

    // timing_debug debug1(
    //     .clk_27m(clk_27m),
    //     .clk_108m(clk_108m),
    //     .reset_n(bus_reset_n),
    //     .bus_iorq_n(bus_iorq_n),
    //     .bus_mreq_n(bus_mreq_n),
    //     .bus_rd_n(bus_rd_n),
    //     .bus_wr_n(bus_wr_n),
    //     .send(send),

    //     .uart_tx(uart_tx)
    // );

    // Switched I/O ports
    reg [1:0] Slot2Mode;
    wire  swio_req;
    wire [7:0] io42_id212;
    wire iSlt2_linear;
    wire swio_req;
    wire swio_req_r;
    wire swio_req_w;
    wire [7:0] swio_dout;
    assign swio_req_r = (config_enable_megaram == 1 && bus_addr[7:4] == 4'b0100 && bus_iorq_n == 0 && bus_m1_n == 1 && bus_rd_n == 0)? 1:0;
    assign swio_req_w = (config_enable_megaram == 1 && bus_addr[7:4] == 4'b0100 && bus_iorq_n == 0 && bus_m1_n == 1 && bus_wr_n == 0)? 1:0;
    assign swio_req = swio_req_r | swio_req_w;

    switched_io_ports ocm_ports (
            .clk21m        (clk_27m),
            .reset         (~bus_reset_n) ,
            .power_on_reset(1),
            .req           (swio_req   ),
            .ack           (           ),
            .wrt           (~bus_wr_n ),
            .adr           (bus_addr   ),
            .dbi           (swio_dout     ),
            .dbo           (cpu_dout      ),
            .io42_id212    (io42_id212    ),
            .iSlt2_linear  (iSlt2_linear  )
        );

    // virtual DIP-SW assignment (2/2)
    always @ ( posedge clk_27m )  begin
        Slot2Mode[1]    <=  io42_id212[4];
        Slot2Mode[0]    <=  io42_id212[5];
    end

    wire send;
    monostable mono2 (
        .pulse_in(s2),
        .clock(clk_27m),
        .pulse_out(send)
    );

   msx2p_debug debug (
       .clk_27m(clk_27m),
       .clk (clk_27m),
       .reset_n ( bus_reset_n ),
       .clk_enable (clk_enable_3m6_27),
       .bus_addr(bus_addr),
       .bus_data(cpu_din),
       .bus_iorq_n(bus_iorq_n),
       .bus_mreq_n(bus_mreq_n),
       .bus_wr_n(bus_wr_n),
       .send(send),
       .uart_tx(uart_tx),
       .boot_ok( )
   );

wire [127:0] keyboard;
fpga_companion fpga_companion_inst
(
    .clk (clk_27m),
    .reset (~bus_reset_n),

    .m0s (m0s),

`ifdef USE_DOCK_JOISTICK
    .spi_sclk (1'b0),
    .spi_csn (1'b1),
    .spi_dir (),
    .spi_dat (1'b0),
    .spi_irqn (),
`else
    .spi_sclk (spi_sclk),
    .spi_csn (spi_csn),
    .spi_dir (spi_dir),
    .spi_dat (spi_dat),
    .spi_irqn (spi_irqn),
`endif

	.keyboard (keyboard)
	// joystick0 => joystick0,
	// joystick0_console => joystick0_console,
	// joystick1 => joystick1,

    // ws2812_color =>  ws2812_color
);

`ifndef ENABLE_PS2KEYBOARD
usb_keyboard_msx usb_keyboard_msx
    (
        .CLK (clk_27m),
        .RESET (~bus_reset_n),

        .keyboard (keyboard),
        .A (keyboard_addr),
        .DO (keyboard_data),
        .FN (function_keys)
    );
`endif

`ifdef ENABLE_PS2KEYBOARD
// PS/2のスキャンコードをUSB HID keycodeベクタへ変換し、MSXマトリクスへの
// マッピング処理そのものは usb_keyboard_msx (USBキーボードと共通) に任せる。
wire [127:0] keyboard_ps2;
ps2_hid_bridge ps2_hid_bridge_inst
    (
        .CLK (clk_27m),
        .RESET (~bus_reset_n),

        .keyboard (keyboard_ps2),

        // ★Dock BoardのPS/2物理ピンを直接アサインする
        .ps2_clk  (ps2_clk),
        .ps2_data (ps2_data)
    );

usb_keyboard_msx usb_keyboard_msx
    (
        .CLK (clk_27m),
        .RESET (~bus_reset_n),

        .keyboard (keyboard_ps2),
        .A (keyboard_addr),
        .DO (keyboard_data),
        .FN (function_keys)
    );
`endif

endmodule