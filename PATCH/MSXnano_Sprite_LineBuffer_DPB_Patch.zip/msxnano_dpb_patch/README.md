# MSXnano Sprite Line Buffer DPB統合パッチ（試作）

## 内容
- `sprite_linebuf_dp.vhd`: 512×8bit、2ポート読み書き可能なRAM。
- `vdp_sprite.vhd`: 元の `U_EVEN_LINE_BUF` / `U_ODD_LINE_BUF` を `U_SHARED_LINE_BUF` に置換。

## 適用
元の `fpga/tn_vdp_v3_v9958/src/vdp/vdp_sprite.vhd` をバックアップし、本パッチの同名ファイルで置換する。`sprite_linebuf_dp.vhd` を同じVHDLソース群へ追加し、Gowinプロジェクトにも登録する。既存のDOCK用top.vなどは変更しない。

## 注意
- 現在のシミュレーション・合成ツール環境にはGHDL/Gowin EDAがないため、RTLのコンパイル、BSRAM個数、タイミングは**未検証**。
- RAMの読み出しアドレスを登録する方式は元の `RAM` と同じ。ただし書き込みと読み出しの同一アドレス衝突時の挙動はデバイス固有のため、実機合成後に検証すること。
- 既存RTLの `SPLINEBUFADDR_E/O` 等の未使用信号は残したまま。削除は動作確認後。
- 2ポート同一アドレスへの書き込みは、表示バンクと描画バンクが異なる前提で起きない。
- 元の `RAM` の初期値と合わせてゼロ初期化を記述。電源投入時の初期化推論はGowinで要確認。
- 本パッチはBSRAM統合だけを対象とし、Sprite Mode 3は未実装。
